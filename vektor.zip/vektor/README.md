# vektor — Übergabepaket

Potrace-basierter Browser-Vektorisierer als web-base-PWA. Einstieg: `PLAN.md`.

**Verifizierter Stand (Container, 2026-07-01):**
- `tsc --noEmit` strict: sauber (lib ES2022 + WebWorker, DOM-frei)
- Tests: 14/14 grün (`tests/potrace.test.ts`, bun:test-Syntax,
  im Container via esbuild+Shim ausgeführt — `bun test` im Zielrepo)

**Übernehmen:** `src/`, `tests/`, `docs/`, `PLAN.md`, `reference/prototype.html`
**Löschen nach Scaffold:** `types/`, `.verify/`, diese `package.json`/`tsconfig.json`
