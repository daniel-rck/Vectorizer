declare module "bun:test" {
  export function describe(name: string, fn: () => void): void;
  export function test(name: string, fn: () => void | Promise<void>): void;
  export function expect(v: unknown): {
    toBe(e: unknown): void;
    toEqual(e: unknown): void;
    toBeNull(): void;
    not: { toBeNull(): void; toMatch(e: RegExp): void; toContain(e: string): void };
    toBeGreaterThan(e: number): void;
    toBeLessThan(e: number): void;
    toBeLessThanOrEqual(e: number): void;
    toContain(e: string): void;
    toMatch(e: RegExp): void;
  };
}
